# Lifestyle-Ecommerce-Website
Simple front-end design for ecommerce website implemented in HTML, CSS & Bootstrap.


Visit link to preview :- https://tarandeep97.github.io/Lifestyle-Ecommerce-Website/

### Screenshots:
![screenshot 100](https://user-images.githubusercontent.com/28994081/47411649-15bc0300-d787-11e8-81fc-55d51d1c2b32.png)

![screenshot 97](https://user-images.githubusercontent.com/28994081/47411712-40a65700-d787-11e8-9ff9-6abd4400d2b5.png)

![screenshot 98](https://user-images.githubusercontent.com/28994081/47411758-6895ba80-d787-11e8-83fe-8bcbf6a9f335.png)
